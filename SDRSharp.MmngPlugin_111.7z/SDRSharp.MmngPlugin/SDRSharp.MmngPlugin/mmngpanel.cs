﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace SDRSharp.MmngPlugin
{
    public partial class mmngpanel : UserControl
    {
        private const string MULTIMON_PROCESS = "multimon-ng";
        private const string SETTING_FN = "multimon-ng-path.txt";

        public mmngpanel()
        {
            InitializeComponent();
            try
            {
                textboxPath.Text = File.ReadAllText(SETTING_FN);
            }
            catch (Exception) { textboxPath.Text = ""; }
        }

        private void buttonPath_Click(object sender, EventArgs e)
        {
            if (openFileDialogMmng.ShowDialog() == DialogResult.OK)
            {
                textboxPath.Text = openFileDialogMmng.FileName;
                try
                {
                    File.WriteAllText(SETTING_FN, textboxPath.Text);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        }

        private void killDSD()
        {
            foreach (var process in Process.GetProcessesByName(MULTIMON_PROCESS))
            {

                process.Kill();
                process.WaitForExit();
            }
        }

        private void buttonKill_Click(object sender, EventArgs e)
        {
            killDSD();
            buttonStart.Enabled = true;
            buttonKill.Enabled = false;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            killDSD();
            textBoxCmd.Clear();
            StringBuilder mmngParams = new StringBuilder("");
            CheckBox checkBoxMode = new CheckBox();
            for (int i = 0; i < panelModes.Controls.Count; i++)
            {
                if (panelModes.Controls[i] is CheckBox)
                {
                    checkBoxMode = (CheckBox) panelModes.Controls[i];
                    if (checkBoxMode.Checked)
                    {
                        mmngParams.Append(" -a " + checkBoxMode.Text);
                    }
                }
            }
            if (checkBoxVerbosity.Checked)
            {
                mmngParams.Append(" -v " + numericUpDownVerbosity.Value.ToString());
            }
            if (checkBoxFMS.Checked)
            {
                mmngParams.Append(" -j");
            }
            if (checkBoxTimestamp.Checked)
            {
                mmngParams.Append(" --timestamp");
            }
            if (checkBoxAPRS.Checked)
            {
                mmngParams.Append(" -A");
            }
            if (checkBoxFlush.Checked)
            {
                mmngParams.Append(" -n");
            }
            if (checkBoxE.Checked)
            {
                mmngParams.Append(" -e");
            }
            if (checkBoxU.Checked)
            {
                mmngParams.Append(" -u");
            }
            if (checkBoxI.Checked)
            {
                mmngParams.Append(" -i");
            }
            if (checkBoxP.Checked)
            {
                mmngParams.Append(" -p");
            }

            buttonStart.Enabled = false;
            buttonKill.Enabled = true;
            try
            {
                using (Process execProcess = new Process())
                {
                    execProcess.StartInfo.UseShellExecute = false;
                    execProcess.StartInfo.FileName = "cmd.exe"; //textboxPath.Text;
                    execProcess.StartInfo.CreateNoWindow = false;
                    execProcess.StartInfo.Arguments = "/C " + textboxPath.Text + " " + mmngParams.ToString();
                    if (checkBoxStdout.Checked)
                    {
                        execProcess.StartInfo.Arguments = execProcess.StartInfo.Arguments + " >multimon_" +
                        DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";
                    }
                    textBoxCmd.Text = execProcess.StartInfo.Arguments.Remove(0, 3);
                    execProcess.Start();
                }
            }
            catch (Exception ex)
            {
                buttonStart.Enabled = true;
                buttonKill.Enabled = false;
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
