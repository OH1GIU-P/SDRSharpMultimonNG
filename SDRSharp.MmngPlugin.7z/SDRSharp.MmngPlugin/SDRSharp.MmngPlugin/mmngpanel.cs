﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace SDRSharp.MmngPlugin
{
    public partial class mmngpanel : UserControl
    {
        private const string MULTIMON_PROCESS = "multimon-ng";

        public mmngpanel()
        {
            InitializeComponent();
        }

        private void buttonPath_Click(object sender, EventArgs e)
        {
            if (openFileDialogMmng.ShowDialog() == DialogResult.OK)
            {
                textboxPath.Text = openFileDialogMmng.FileName;
            }
        }

        private void killDSD()
        {
            foreach (var process in Process.GetProcessesByName(MULTIMON_PROCESS))
            {

                process.Kill();
                process.WaitForExit();
            }
        }

        private void buttonKill_Click(object sender, EventArgs e)
        {
            killDSD();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            killDSD();
            StringBuilder mmngParams = new StringBuilder("");
            CheckBox checkBoxMode = new CheckBox();
            for (int i = 0; i < panelModes.Controls.Count; i++)
            {
                if (panelModes.Controls[i] is CheckBox)
                {
                    checkBoxMode = (CheckBox) panelModes.Controls[i];
                    if (checkBoxMode.Checked)
                    {
                        mmngParams.Append(" -a " + checkBoxMode.Text);
                    }
                }
            }
            if (checkBoxVerbosity.Checked)
            {
                mmngParams.Append(" -v " + numericUpDownVerbosity.Value.ToString());
            }
            if (checkBoxFlush.Checked)
            {
                mmngParams.Append(" -n");
            }

            try
            {
                using (Process execProcess = new Process())
                {
                    execProcess.StartInfo.UseShellExecute = false;
                    execProcess.StartInfo.FileName = textboxPath.Text;
                    execProcess.StartInfo.CreateNoWindow = false;
                    execProcess.StartInfo.Arguments = mmngParams.ToString();
                    execProcess.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

    }
}
