﻿namespace SDRSharp.MmngPlugin
{
    partial class mmngpanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelMmngPath = new System.Windows.Forms.Label();
            this.textboxPath = new System.Windows.Forms.TextBox();
            this.buttonPath = new System.Windows.Forms.Button();
            this.openFileDialogMmng = new System.Windows.Forms.OpenFileDialog();
            this.checkBoxVerbosity = new System.Windows.Forms.CheckBox();
            this.numericUpDownVerbosity = new System.Windows.Forms.NumericUpDown();
            this.toolTipVerbosity = new System.Windows.Forms.ToolTip(this.components);
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonKill = new System.Windows.Forms.Button();
            this.panelModes = new System.Windows.Forms.Panel();
            this.checkBoxCcir = new System.Windows.Forms.CheckBox();
            this.checkBoxEia = new System.Windows.Forms.CheckBox();
            this.checkBoxEea = new System.Windows.Forms.CheckBox();
            this.checkBoxZvei3 = new System.Windows.Forms.CheckBox();
            this.checkBoxZvei2 = new System.Windows.Forms.CheckBox();
            this.checkBoxZvei1 = new System.Windows.Forms.CheckBox();
            this.checkBoxDtmf = new System.Windows.Forms.CheckBox();
            this.checkBoxFsk9600 = new System.Windows.Forms.CheckBox();
            this.checkBoxAfsk2400_3 = new System.Windows.Forms.CheckBox();
            this.checkBoxAfsk2400_2 = new System.Windows.Forms.CheckBox();
            this.checkBoxAfsk2400 = new System.Windows.Forms.CheckBox();
            this.checkBoxAfsk1200 = new System.Windows.Forms.CheckBox();
            this.checkBoxEas = new System.Windows.Forms.CheckBox();
            this.checkBoxPocsag2400 = new System.Windows.Forms.CheckBox();
            this.checkBoxPocsag1200 = new System.Windows.Forms.CheckBox();
            this.checkBoxPocsag512 = new System.Windows.Forms.CheckBox();
            this.checkBoxFlex = new System.Windows.Forms.CheckBox();
            this.checkBoxClipFSK = new System.Windows.Forms.CheckBox();
            this.checkBoxUfsk1200 = new System.Windows.Forms.CheckBox();
            this.checkBoxFmsFSK = new System.Windows.Forms.CheckBox();
            this.checkBoxFlex_next = new System.Windows.Forms.CheckBox();
            this.checkBoxFlush = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVerbosity)).BeginInit();
            this.panelModes.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelMmngPath
            // 
            this.labelMmngPath.AutoSize = true;
            this.labelMmngPath.Location = new System.Drawing.Point(4, 4);
            this.labelMmngPath.Name = "labelMmngPath";
            this.labelMmngPath.Size = new System.Drawing.Size(88, 13);
            this.labelMmngPath.TabIndex = 0;
            this.labelMmngPath.Text = "Multimon-ng path";
            // 
            // textboxPath
            // 
            this.textboxPath.Location = new System.Drawing.Point(7, 32);
            this.textboxPath.Name = "textboxPath";
            this.textboxPath.ReadOnly = true;
            this.textboxPath.Size = new System.Drawing.Size(200, 20);
            this.textboxPath.TabIndex = 2;
            // 
            // buttonPath
            // 
            this.buttonPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPath.Location = new System.Drawing.Point(102, 3);
            this.buttonPath.Name = "buttonPath";
            this.buttonPath.Size = new System.Drawing.Size(75, 22);
            this.buttonPath.TabIndex = 1;
            this.buttonPath.Text = "Multimon ...";
            this.buttonPath.UseVisualStyleBackColor = true;
            this.buttonPath.Click += new System.EventHandler(this.buttonPath_Click);
            // 
            // openFileDialogMmng
            // 
            this.openFileDialogMmng.DefaultExt = "exe";
            this.openFileDialogMmng.Filter = "Multimon|multimon-ng.exe";
            this.openFileDialogMmng.InitialDirectory = "c:\\";
            // 
            // checkBoxVerbosity
            // 
            this.checkBoxVerbosity.AutoSize = true;
            this.checkBoxVerbosity.Location = new System.Drawing.Point(17, 345);
            this.checkBoxVerbosity.Name = "checkBoxVerbosity";
            this.checkBoxVerbosity.Size = new System.Drawing.Size(32, 17);
            this.checkBoxVerbosity.TabIndex = 19;
            this.checkBoxVerbosity.Text = "v";
            this.toolTipVerbosity.SetToolTip(this.checkBoxVerbosity, "Verbosity level  1 - 10. Default is 2");
            this.checkBoxVerbosity.UseVisualStyleBackColor = true;
            // 
            // numericUpDownVerbosity
            // 
            this.numericUpDownVerbosity.Location = new System.Drawing.Point(110, 342);
            this.numericUpDownVerbosity.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownVerbosity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownVerbosity.Name = "numericUpDownVerbosity";
            this.numericUpDownVerbosity.ReadOnly = true;
            this.numericUpDownVerbosity.Size = new System.Drawing.Size(47, 20);
            this.numericUpDownVerbosity.TabIndex = 20;
            this.numericUpDownVerbosity.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // toolTipVerbosity
            // 
            this.toolTipVerbosity.ShowAlways = true;
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(7, 394);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(94, 23);
            this.buttonStart.TabIndex = 21;
            this.buttonStart.Text = "Start Multimon";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonKill
            // 
            this.buttonKill.Location = new System.Drawing.Point(111, 394);
            this.buttonKill.Name = "buttonKill";
            this.buttonKill.Size = new System.Drawing.Size(94, 23);
            this.buttonKill.TabIndex = 22;
            this.buttonKill.Text = "Kill Multimon";
            this.buttonKill.UseVisualStyleBackColor = true;
            this.buttonKill.Click += new System.EventHandler(this.buttonKill_Click);
            // 
            // panelModes
            // 
            this.panelModes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelModes.Controls.Add(this.checkBoxFlex_next);
            this.panelModes.Controls.Add(this.checkBoxFmsFSK);
            this.panelModes.Controls.Add(this.checkBoxUfsk1200);
            this.panelModes.Controls.Add(this.checkBoxClipFSK);
            this.panelModes.Controls.Add(this.checkBoxFlex);
            this.panelModes.Controls.Add(this.checkBoxCcir);
            this.panelModes.Controls.Add(this.checkBoxEia);
            this.panelModes.Controls.Add(this.checkBoxEea);
            this.panelModes.Controls.Add(this.checkBoxZvei3);
            this.panelModes.Controls.Add(this.checkBoxZvei2);
            this.panelModes.Controls.Add(this.checkBoxZvei1);
            this.panelModes.Controls.Add(this.checkBoxDtmf);
            this.panelModes.Controls.Add(this.checkBoxFsk9600);
            this.panelModes.Controls.Add(this.checkBoxAfsk2400_3);
            this.panelModes.Controls.Add(this.checkBoxAfsk2400_2);
            this.panelModes.Controls.Add(this.checkBoxAfsk2400);
            this.panelModes.Controls.Add(this.checkBoxAfsk1200);
            this.panelModes.Controls.Add(this.checkBoxEas);
            this.panelModes.Controls.Add(this.checkBoxPocsag2400);
            this.panelModes.Controls.Add(this.checkBoxPocsag1200);
            this.panelModes.Controls.Add(this.checkBoxPocsag512);
            this.panelModes.Location = new System.Drawing.Point(7, 58);
            this.panelModes.Name = "panelModes";
            this.panelModes.Size = new System.Drawing.Size(200, 266);
            this.panelModes.TabIndex = 23;
            // 
            // checkBoxCcir
            // 
            this.checkBoxCcir.AutoSize = true;
            this.checkBoxCcir.Location = new System.Drawing.Point(103, 164);
            this.checkBoxCcir.Name = "checkBoxCcir";
            this.checkBoxCcir.Size = new System.Drawing.Size(51, 17);
            this.checkBoxCcir.TabIndex = 34;
            this.checkBoxCcir.Text = "CCIR";
            this.checkBoxCcir.UseVisualStyleBackColor = true;
            // 
            // checkBoxEia
            // 
            this.checkBoxEia.AutoSize = true;
            this.checkBoxEia.Location = new System.Drawing.Point(8, 164);
            this.checkBoxEia.Name = "checkBoxEia";
            this.checkBoxEia.Size = new System.Drawing.Size(43, 17);
            this.checkBoxEia.TabIndex = 33;
            this.checkBoxEia.Text = "EIA";
            this.checkBoxEia.UseVisualStyleBackColor = true;
            // 
            // checkBoxEea
            // 
            this.checkBoxEea.AutoSize = true;
            this.checkBoxEea.Location = new System.Drawing.Point(103, 141);
            this.checkBoxEea.Name = "checkBoxEea";
            this.checkBoxEea.Size = new System.Drawing.Size(47, 17);
            this.checkBoxEea.TabIndex = 32;
            this.checkBoxEea.Text = "EEA";
            this.checkBoxEea.UseVisualStyleBackColor = true;
            // 
            // checkBoxZvei3
            // 
            this.checkBoxZvei3.AutoSize = true;
            this.checkBoxZvei3.Location = new System.Drawing.Point(8, 141);
            this.checkBoxZvei3.Name = "checkBoxZvei3";
            this.checkBoxZvei3.Size = new System.Drawing.Size(56, 17);
            this.checkBoxZvei3.TabIndex = 31;
            this.checkBoxZvei3.Text = "ZVEI3";
            this.checkBoxZvei3.UseVisualStyleBackColor = true;
            // 
            // checkBoxZvei2
            // 
            this.checkBoxZvei2.AutoSize = true;
            this.checkBoxZvei2.Location = new System.Drawing.Point(103, 118);
            this.checkBoxZvei2.Name = "checkBoxZvei2";
            this.checkBoxZvei2.Size = new System.Drawing.Size(56, 17);
            this.checkBoxZvei2.TabIndex = 30;
            this.checkBoxZvei2.Text = "ZVEI2";
            this.checkBoxZvei2.UseVisualStyleBackColor = true;
            // 
            // checkBoxZvei1
            // 
            this.checkBoxZvei1.AutoSize = true;
            this.checkBoxZvei1.Location = new System.Drawing.Point(8, 118);
            this.checkBoxZvei1.Name = "checkBoxZvei1";
            this.checkBoxZvei1.Size = new System.Drawing.Size(56, 17);
            this.checkBoxZvei1.TabIndex = 29;
            this.checkBoxZvei1.Text = "ZVEI1";
            this.checkBoxZvei1.UseVisualStyleBackColor = true;
            // 
            // checkBoxDtmf
            // 
            this.checkBoxDtmf.AutoSize = true;
            this.checkBoxDtmf.Location = new System.Drawing.Point(103, 95);
            this.checkBoxDtmf.Name = "checkBoxDtmf";
            this.checkBoxDtmf.Size = new System.Drawing.Size(56, 17);
            this.checkBoxDtmf.TabIndex = 28;
            this.checkBoxDtmf.Text = "DTMF";
            this.checkBoxDtmf.UseVisualStyleBackColor = true;
            // 
            // checkBoxFsk9600
            // 
            this.checkBoxFsk9600.AutoSize = true;
            this.checkBoxFsk9600.Location = new System.Drawing.Point(8, 95);
            this.checkBoxFsk9600.Name = "checkBoxFsk9600";
            this.checkBoxFsk9600.Size = new System.Drawing.Size(70, 17);
            this.checkBoxFsk9600.TabIndex = 27;
            this.checkBoxFsk9600.Text = "FSK9600";
            this.checkBoxFsk9600.UseVisualStyleBackColor = true;
            // 
            // checkBoxAfsk2400_3
            // 
            this.checkBoxAfsk2400_3.AutoSize = true;
            this.checkBoxAfsk2400_3.Location = new System.Drawing.Point(103, 72);
            this.checkBoxAfsk2400_3.Name = "checkBoxAfsk2400_3";
            this.checkBoxAfsk2400_3.Size = new System.Drawing.Size(89, 17);
            this.checkBoxAfsk2400_3.TabIndex = 26;
            this.checkBoxAfsk2400_3.Text = "AFSK2400_3";
            this.checkBoxAfsk2400_3.UseVisualStyleBackColor = true;
            // 
            // checkBoxAfsk2400_2
            // 
            this.checkBoxAfsk2400_2.AutoSize = true;
            this.checkBoxAfsk2400_2.Location = new System.Drawing.Point(8, 72);
            this.checkBoxAfsk2400_2.Name = "checkBoxAfsk2400_2";
            this.checkBoxAfsk2400_2.Size = new System.Drawing.Size(89, 17);
            this.checkBoxAfsk2400_2.TabIndex = 25;
            this.checkBoxAfsk2400_2.Text = "AFSK2400_2";
            this.checkBoxAfsk2400_2.UseVisualStyleBackColor = true;
            // 
            // checkBoxAfsk2400
            // 
            this.checkBoxAfsk2400.AutoSize = true;
            this.checkBoxAfsk2400.Location = new System.Drawing.Point(103, 49);
            this.checkBoxAfsk2400.Name = "checkBoxAfsk2400";
            this.checkBoxAfsk2400.Size = new System.Drawing.Size(77, 17);
            this.checkBoxAfsk2400.TabIndex = 24;
            this.checkBoxAfsk2400.Text = "AFSK2400";
            this.checkBoxAfsk2400.UseVisualStyleBackColor = true;
            // 
            // checkBoxAfsk1200
            // 
            this.checkBoxAfsk1200.AutoSize = true;
            this.checkBoxAfsk1200.Location = new System.Drawing.Point(8, 49);
            this.checkBoxAfsk1200.Name = "checkBoxAfsk1200";
            this.checkBoxAfsk1200.Size = new System.Drawing.Size(77, 17);
            this.checkBoxAfsk1200.TabIndex = 23;
            this.checkBoxAfsk1200.Text = "AFSK1200";
            this.checkBoxAfsk1200.UseVisualStyleBackColor = true;
            // 
            // checkBoxEas
            // 
            this.checkBoxEas.AutoSize = true;
            this.checkBoxEas.Location = new System.Drawing.Point(103, 26);
            this.checkBoxEas.Name = "checkBoxEas";
            this.checkBoxEas.Size = new System.Drawing.Size(47, 17);
            this.checkBoxEas.TabIndex = 22;
            this.checkBoxEas.Text = "EAS";
            this.checkBoxEas.UseVisualStyleBackColor = true;
            // 
            // checkBoxPocsag2400
            // 
            this.checkBoxPocsag2400.AutoSize = true;
            this.checkBoxPocsag2400.Location = new System.Drawing.Point(8, 26);
            this.checkBoxPocsag2400.Name = "checkBoxPocsag2400";
            this.checkBoxPocsag2400.Size = new System.Drawing.Size(94, 17);
            this.checkBoxPocsag2400.TabIndex = 21;
            this.checkBoxPocsag2400.Text = "POCSAG2400";
            this.checkBoxPocsag2400.UseVisualStyleBackColor = true;
            // 
            // checkBoxPocsag1200
            // 
            this.checkBoxPocsag1200.AutoSize = true;
            this.checkBoxPocsag1200.Location = new System.Drawing.Point(103, 3);
            this.checkBoxPocsag1200.Name = "checkBoxPocsag1200";
            this.checkBoxPocsag1200.Size = new System.Drawing.Size(94, 17);
            this.checkBoxPocsag1200.TabIndex = 20;
            this.checkBoxPocsag1200.Text = "POCSAG1200";
            this.checkBoxPocsag1200.UseVisualStyleBackColor = true;
            // 
            // checkBoxPocsag512
            // 
            this.checkBoxPocsag512.AutoSize = true;
            this.checkBoxPocsag512.Location = new System.Drawing.Point(8, 3);
            this.checkBoxPocsag512.Name = "checkBoxPocsag512";
            this.checkBoxPocsag512.Size = new System.Drawing.Size(88, 17);
            this.checkBoxPocsag512.TabIndex = 19;
            this.checkBoxPocsag512.Text = "POCSAG512";
            this.checkBoxPocsag512.UseVisualStyleBackColor = true;
            // 
            // checkBoxFlex
            // 
            this.checkBoxFlex.AutoSize = true;
            this.checkBoxFlex.Location = new System.Drawing.Point(8, 187);
            this.checkBoxFlex.Name = "checkBoxFlex";
            this.checkBoxFlex.Size = new System.Drawing.Size(52, 17);
            this.checkBoxFlex.TabIndex = 35;
            this.checkBoxFlex.Text = "FLEX";
            this.checkBoxFlex.UseVisualStyleBackColor = true;
            // 
            // checkBoxClipFSK
            // 
            this.checkBoxClipFSK.AutoSize = true;
            this.checkBoxClipFSK.Location = new System.Drawing.Point(103, 187);
            this.checkBoxClipFSK.Name = "checkBoxClipFSK";
            this.checkBoxClipFSK.Size = new System.Drawing.Size(69, 17);
            this.checkBoxClipFSK.TabIndex = 36;
            this.checkBoxClipFSK.Text = "CLIPFSK";
            this.checkBoxClipFSK.UseVisualStyleBackColor = true;
            // 
            // checkBoxUfsk1200
            // 
            this.checkBoxUfsk1200.AutoSize = true;
            this.checkBoxUfsk1200.Location = new System.Drawing.Point(8, 211);
            this.checkBoxUfsk1200.Name = "checkBoxUfsk1200";
            this.checkBoxUfsk1200.Size = new System.Drawing.Size(78, 17);
            this.checkBoxUfsk1200.TabIndex = 37;
            this.checkBoxUfsk1200.Text = "UFSK1200";
            this.checkBoxUfsk1200.UseVisualStyleBackColor = true;
            // 
            // checkBoxFmsFSK
            // 
            this.checkBoxFmsFSK.AutoSize = true;
            this.checkBoxFmsFSK.Location = new System.Drawing.Point(103, 211);
            this.checkBoxFmsFSK.Name = "checkBoxFmsFSK";
            this.checkBoxFmsFSK.Size = new System.Drawing.Size(68, 17);
            this.checkBoxFmsFSK.TabIndex = 38;
            this.checkBoxFmsFSK.Text = "FMSFSK";
            this.checkBoxFmsFSK.UseVisualStyleBackColor = true;
            // 
            // checkBoxFlex_next
            // 
            this.checkBoxFlex_next.AutoSize = true;
            this.checkBoxFlex_next.Location = new System.Drawing.Point(8, 234);
            this.checkBoxFlex_next.Name = "checkBoxFlex_next";
            this.checkBoxFlex_next.Size = new System.Drawing.Size(87, 17);
            this.checkBoxFlex_next.TabIndex = 39;
            this.checkBoxFlex_next.Text = "FLEX_NEXT";
            this.checkBoxFlex_next.UseVisualStyleBackColor = true;
            // 
            // checkBoxFlush
            // 
            this.checkBoxFlush.AutoSize = true;
            this.checkBoxFlush.Location = new System.Drawing.Point(17, 368);
            this.checkBoxFlush.Name = "checkBoxFlush";
            this.checkBoxFlush.Size = new System.Drawing.Size(122, 17);
            this.checkBoxFlush.TabIndex = 24;
            this.checkBoxFlush.Text = "-- n dont flush stdout";
            this.toolTipVerbosity.SetToolTip(this.checkBoxFlush, "Verbosity level  1 - 10. Default is 2");
            this.checkBoxFlush.UseVisualStyleBackColor = true;
            // 
            // mmngpanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.checkBoxFlush);
            this.Controls.Add(this.panelModes);
            this.Controls.Add(this.buttonKill);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.numericUpDownVerbosity);
            this.Controls.Add(this.checkBoxVerbosity);
            this.Controls.Add(this.buttonPath);
            this.Controls.Add(this.textboxPath);
            this.Controls.Add(this.labelMmngPath);
            this.Name = "mmngpanel";
            this.Size = new System.Drawing.Size(213, 466);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVerbosity)).EndInit();
            this.panelModes.ResumeLayout(false);
            this.panelModes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelMmngPath;
        private System.Windows.Forms.TextBox textboxPath;
        private System.Windows.Forms.Button buttonPath;
        private System.Windows.Forms.OpenFileDialog openFileDialogMmng;
        private System.Windows.Forms.CheckBox checkBoxVerbosity;
        private System.Windows.Forms.NumericUpDown numericUpDownVerbosity;
        private System.Windows.Forms.ToolTip toolTipVerbosity;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonKill;
        private System.Windows.Forms.Panel panelModes;
        private System.Windows.Forms.CheckBox checkBoxCcir;
        private System.Windows.Forms.CheckBox checkBoxEia;
        private System.Windows.Forms.CheckBox checkBoxEea;
        private System.Windows.Forms.CheckBox checkBoxZvei3;
        private System.Windows.Forms.CheckBox checkBoxZvei2;
        private System.Windows.Forms.CheckBox checkBoxZvei1;
        private System.Windows.Forms.CheckBox checkBoxDtmf;
        private System.Windows.Forms.CheckBox checkBoxFsk9600;
        private System.Windows.Forms.CheckBox checkBoxAfsk2400_3;
        private System.Windows.Forms.CheckBox checkBoxAfsk2400_2;
        private System.Windows.Forms.CheckBox checkBoxAfsk2400;
        private System.Windows.Forms.CheckBox checkBoxAfsk1200;
        private System.Windows.Forms.CheckBox checkBoxEas;
        private System.Windows.Forms.CheckBox checkBoxPocsag2400;
        private System.Windows.Forms.CheckBox checkBoxPocsag1200;
        private System.Windows.Forms.CheckBox checkBoxPocsag512;
        private System.Windows.Forms.CheckBox checkBoxFlex;
        private System.Windows.Forms.CheckBox checkBoxClipFSK;
        private System.Windows.Forms.CheckBox checkBoxUfsk1200;
        private System.Windows.Forms.CheckBox checkBoxFmsFSK;
        private System.Windows.Forms.CheckBox checkBoxFlex_next;
        private System.Windows.Forms.CheckBox checkBoxFlush;
    }
}
