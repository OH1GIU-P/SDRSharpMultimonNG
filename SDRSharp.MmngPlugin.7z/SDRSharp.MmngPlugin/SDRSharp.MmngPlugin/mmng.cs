﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDRSharp.Common;

namespace SDRSharp.MmngPlugin
{
    public class mmng : ISharpPlugin
    {
        private const string _displayName = "Multimon-ng";
        private ISharpControl _control;
        private mmngpanel _guiControl;

        public UserControl Gui
        {
            get { return _guiControl; }
        }

        public string DisplayName
        {
            get { return _displayName; }
        }

        public void Close()
        {
        }

        public void Initialize(ISharpControl control)
        {
            _control = control;
            _guiControl = new mmngpanel();
        }
    }
}
